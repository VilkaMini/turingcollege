class calculator:

    def __init__(self, memory: float = 0.0):
        self.memory = memory

    def add(self, a: float, b: float = None):
        if (b == None):
            self.memory += a
            return self.memory
        else:
            return a + b

    def subtract(self, a: float, b: float = None):
        if (b == None):
            self.memory -= a
            return self.memory
        else:
            return a - b
    
    def multiply(self, a: float, b: float = None):
        if (b == None):
            self.memory *= a
            return self.memory
        else:
            return a * b

    def divide(self, a: float, b: float = None):
        if (b == None):
            self.memory /= a
            return self.memory
        else:
            return a / b

    def n_root(self, a: float, b: float = None):
        if (b == None):
            self.memory = self.memory**(1.0/a)
            return self.memory
        else:
            return b**(1.0/a)

    def show_memory(self):
        return f"Number in calculators memory: {self.memory}"

    def reset_memory(self):
        self.memory = 0.0
        self.show_memory()
        