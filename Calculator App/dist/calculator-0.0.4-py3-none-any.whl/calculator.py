class calculator:

    @staticmethod
    def add(a: int = 0, b: int = 0):
        return a + b
    
    @staticmethod
    def subtract(a: int = 0, b: int = 0):
        return a - b
    
    @staticmethod
    def multiply(a: int = 0, b: int = 0):
        return a * b
    
    @staticmethod
    def divide(a: int = 0, b: int = 0):
        return a / b

    @staticmethod
    def n_root(n: int = 0, a: int = 0):
        return a**(1.0/n)